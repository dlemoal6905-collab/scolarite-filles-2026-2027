Calendrier scolaire 2026-2027 — version partage Netlify Drop

Version statique autonome, sans dépendance externe.
- Frise annuelle : seul le parent présent est coloré.
- Filtres événements clairement séparés des filtres parent/enfant.
- Les échanges convenus sont fixes et toujours affichés (pas de bouton de masquage).
- Statistiques partagées : nuitées Papa/Maman uniquement.

Déploiement : glisser ce dossier (avec index.html à la racine) dans Netlify Drop.
